# Optimus-mainboard-firmware
Latest firmware for Optimus mainboard
This is the repository that contains the firmware for the OPTIMUS-FEBTOP 3IN1 PRINTER. It's based on the well-known Smoothieware but with some modifications.
Released under the GNU GPL v3, which you can find at http://www.gnu.org/licenses/gpl-3.0.en.html
